<?php
namespace Emipro\Smartproductselector\Model;

class Smartupsell extends \Magento\Framework\Model\AbstractModel
{

    public function _construct()
    {
        $this->_init('Emipro\Smartproductselector\Model\ResourceModel\Smartupsell');
    }
}
