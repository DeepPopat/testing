<?php
namespace Emipro\Smartproductselector\Model;

class Smartcrossell extends \Magento\Framework\Model\AbstractModel
{

    public function _construct()
    {
        $this->_init('Emipro\Smartproductselector\Model\ResourceModel\Smartcrossell');
    }
}
